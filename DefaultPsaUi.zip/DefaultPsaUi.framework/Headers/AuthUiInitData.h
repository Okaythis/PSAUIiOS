//
//  Header.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 1/29/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Payment.h"

@interface AuthUiInitData : NSObject

@property NSAttributedString *description;
@property NSArray<Payment*> *payments;
@property NSInteger timerSeconds;
@property NSAttributedString *confirmActionHeaderText;
@property NSAttributedString *confirmButtonText;
@property NSAttributedString *confirmBiometricTouchButtonText;
@property NSAttributedString *confirmBiometricFaceButtonText;
@property NSAttributedString *cancelButtonText;
@property NSAttributedString *massPaymentDetailsButtonText;
@property NSAttributedString *massPaymentDetailsHeaderText;
@property NSAttributedString *feeLabelText;
@property NSAttributedString *recepientLabelText;

@end
